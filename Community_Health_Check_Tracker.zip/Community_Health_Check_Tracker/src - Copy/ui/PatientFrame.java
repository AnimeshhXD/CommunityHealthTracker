package ui;

import javax.swing.*;
import java.awt.*;

public class PatientFrame extends JFrame {
    private JTextField nameField;
    private JTextField ageField;
    private JComboBox<String> genderCombo;
    private JTextField contactField;
    private JTextField addressField;
    private JButton addPatientButton;
    private JButton updatePatientButton;
    private JButton deletePatientButton;
    private JButton clearButton;
    private JTable patientTable;

    public PatientFrame() {
        setTitle("Manage Patients");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel formPanel = new JPanel(new GridLayout(5, 2, 5, 5));
        nameField = new JTextField();
        ageField = new JTextField();
        genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        contactField = new JTextField();
        addressField = new JTextField();

        formPanel.add(new JLabel("Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Age:"));
        formPanel.add(ageField);
        formPanel.add(new JLabel("Gender:"));
        formPanel.add(genderCombo);
        formPanel.add(new JLabel("Contact:"));
        formPanel.add(contactField);
        formPanel.add(new JLabel("Address:"));
        formPanel.add(addressField);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        addPatientButton = new JButton("Add");
        updatePatientButton = new JButton("Update");
        deletePatientButton = new JButton("Delete");
        clearButton = new JButton("Clear");

        buttonPanel.add(addPatientButton);
        buttonPanel.add(updatePatientButton);
        buttonPanel.add(deletePatientButton);
        buttonPanel.add(clearButton);

        String[] cols = {"ID", "Name", "Age", "Gender", "Contact", "Address"};
        String[][] data = {};
        patientTable = new JTable(data, cols);
        JScrollPane tablePane = new JScrollPane(patientTable);

        add(formPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(tablePane, BorderLayout.SOUTH);
    }
}
