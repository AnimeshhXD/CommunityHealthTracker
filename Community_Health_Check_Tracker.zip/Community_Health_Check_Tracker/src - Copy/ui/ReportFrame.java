package ui;

import javax.swing.*;
import java.awt.*;

public class ReportFrame extends JFrame {
    private JTextField searchField;
    private JButton viewAllReportsButton;
    private JButton searchButton;
    private JTable reportTable;

    public ReportFrame() {
        setTitle("Reports");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Top panel for search
        JPanel topPanel = new JPanel(new FlowLayout());
        searchField = new JTextField(15);
        searchButton = new JButton("Search");
        viewAllReportsButton = new JButton("View All Reports");
        topPanel.add(new JLabel("Enter Patient ID:"));
        topPanel.add(searchField);
        topPanel.add(searchButton);
        topPanel.add(viewAllReportsButton);


        String[] cols = {"Report ID", "Patient ID", "Date", "Details"};
        String[][] data = {};
        reportTable = new JTable(data, cols);
        JScrollPane scrollPane = new JScrollPane(reportTable);


        add(topPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }
}
