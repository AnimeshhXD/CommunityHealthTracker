package ui;

import javax.swing.*;
import java.awt.*;

public class DashboardFrame extends JFrame {
    private JButton managePatientButton;
    private JButton recordCheckupsButton;
    private JButton viewReportsButton;
    private JButton logoutButton;

    public DashboardFrame() {
        setTitle("Dashboard");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(4, 1, 10, 10));
        managePatientButton = new JButton("Manage Patients");
        recordCheckupsButton = new JButton("Record Checkups");
        viewReportsButton = new JButton("View Reports");
        logoutButton = new JButton("Logout");

        panel.add(managePatientButton);
        panel.add(recordCheckupsButton);
        panel.add(viewReportsButton);
        panel.add(logoutButton);

        add(panel, BorderLayout.CENTER);
    }
}
