package ui;

import javax.swing.*;
import java.awt.*;

public class CheckupFrame extends JFrame {
    private JComboBox<String> patientCombo;
    private JTextField doctorField;
    private JTextField dateField;
    private JTextField timeField;
    private JTextArea symptomsArea;
    private JTextArea prescriptionArea;
    private JButton addCheckupButton;
    private JButton clearButton;
    private JButton updateCheckupButton;
    private JButton deleteCheckupButton;
    private JTable checkupTable;

    public CheckupFrame() {
        setTitle("Record Checkups");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel formPanel = new JPanel(new GridLayout(6, 2, 5, 5));
        patientCombo = new JComboBox<>(new String[]{"Patient1", "Patient2"});
        doctorField = new JTextField();
        dateField = new JTextField("DD/MM/YYYY");
        timeField = new JTextField("HH:MM");
        symptomsArea = new JTextArea(3, 20);
        prescriptionArea = new JTextArea(3, 20);

        formPanel.add(new JLabel("Patient:"));
        formPanel.add(patientCombo);
        formPanel.add(new JLabel("Doctor:"));
        formPanel.add(doctorField);
        formPanel.add(new JLabel("Date:"));
        formPanel.add(dateField);
        formPanel.add(new JLabel("Time:"));
        formPanel.add(timeField);
        formPanel.add(new JLabel("Symptoms:"));
        formPanel.add(new JScrollPane(symptomsArea));
        formPanel.add(new JLabel("Prescription:"));
        formPanel.add(new JScrollPane(prescriptionArea));

        JPanel buttonPanel = new JPanel(new FlowLayout());
        addCheckupButton = new JButton("Add");
        updateCheckupButton = new JButton("Update");
        deleteCheckupButton = new JButton("Delete");
        clearButton = new JButton("Clear");

        buttonPanel.add(addCheckupButton);
        buttonPanel.add(updateCheckupButton);
        buttonPanel.add(deleteCheckupButton);
        buttonPanel.add(clearButton);

        String[] cols = {"Checkup ID", "Patient", "Doctor", "Date", "Time", "Symptoms", "Prescription"};
        String[][] data = {};
        checkupTable = new JTable(data, cols);
        JScrollPane tablePane = new JScrollPane(checkupTable);

        add(formPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(tablePane, BorderLayout.SOUTH);
    }
}
