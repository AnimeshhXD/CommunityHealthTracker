package Service;

import model.Checkup;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CheckupService {

    public void addCheckup(Checkup c) {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO checkups(patient_id, date, blood_pressure, weight, symptoms, remarks) VALUES (?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, c.getPatientId());
            ps.setString(2, c.getDate());
            ps.setString(3, c.getBloodPressure());
            ps.setString(4, c.getWeight());
            ps.setString(5, c.getSymptoms());
            ps.setString(6, c.getRemarks());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateCheckup(Checkup c) {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "UPDATE checkups SET date=?, blood_pressure=?, weight=?, symptoms=?, remarks=? WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, c.getDate());
            ps.setString(2, c.getBloodPressure());
            ps.setString(3, c.getWeight());
            ps.setString(4, c.getSymptoms());
            ps.setString(5, c.getRemarks());
            ps.setInt(6, c.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteCheckup(int id) {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "DELETE FROM checkups WHERE id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Checkup> getAllCheckups() {
        List<Checkup> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection()) {
            String sql = "SELECT * FROM checkups";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Checkup c = new Checkup(
                        rs.getInt("id"),
                        rs.getInt("patient_id"),
                        rs.getString("date"),
                        rs.getString("blood_pressure"),
                        rs.getString("weight"),
                        rs.getString("symptoms"),
                        rs.getString("remarks")
                );
                list.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
