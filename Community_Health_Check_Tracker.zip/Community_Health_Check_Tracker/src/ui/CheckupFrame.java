package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import Service.CheckupService;
import Service.PatientService;
import model.Checkup;
import model.Patient;
import java.util.List;

public class CheckupFrame extends JFrame {
    private JComboBox<String> patientCombo;
    private JTextField doctorField, dateField, timeField;
    private JTextArea symptomsArea, prescriptionArea;
    private JButton addButton, updateButton, deleteButton, clearButton;
    private JTable checkupTable;
    private CheckupService checkupService;
    private PatientService patientService;

    public CheckupFrame() {
        setTitle("Record Checkups");
        setSize(800, 600);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel patientLabel = new JLabel("Patient:");
        patientLabel.setBounds(30, 30, 100, 25);
        add(patientLabel);

        patientCombo = new JComboBox<>();
        patientCombo.setBounds(140, 30, 200, 25);
        add(patientCombo);

        JLabel doctorLabel = new JLabel("Doctor:");
        doctorLabel.setBounds(30, 70, 100, 25);
        add(doctorLabel);
        doctorField = new JTextField();
        doctorField.setBounds(140, 70, 200, 25);
        add(doctorField);

        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setBounds(30, 110, 100, 25);
        add(dateLabel);
        dateField = new JTextField();
        dateField.setBounds(140, 110, 200, 25);
        add(dateField);

        JLabel timeLabel = new JLabel("Time:");
        timeLabel.setBounds(30, 150, 100, 25);
        add(timeLabel);
        timeField = new JTextField();
        timeField.setBounds(140, 150, 200, 25);
        add(timeField);

        JLabel symptomsLabel = new JLabel("Symptoms:");
        symptomsLabel.setBounds(30, 190, 100, 25);
        add(symptomsLabel);
        symptomsArea = new JTextArea();
        symptomsArea.setBounds(140, 190, 200, 75);
        add(symptomsArea);

        JLabel prescriptionLabel = new JLabel("Prescription:");
        prescriptionLabel.setBounds(30, 280, 100, 25);
        add(prescriptionLabel);
        prescriptionArea = new JTextArea();
        prescriptionArea.setBounds(140, 280, 200, 75);
        add(prescriptionArea);

        addButton = new JButton("Add");
        addButton.setBounds(50, 370, 100, 30);
        add(addButton);

        updateButton = new JButton("Update");
        updateButton.setBounds(180, 370, 100, 30);
        add(updateButton);

        deleteButton = new JButton("Delete");
        deleteButton.setBounds(310, 370, 100, 30);
        add(deleteButton);

        clearButton = new JButton("Clear");
        clearButton.setBounds(440, 370, 100, 30);
        add(clearButton);

        checkupTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(checkupTable);
        scrollPane.setBounds(30, 420, 720, 150);
        add(scrollPane);

        checkupService = new CheckupService();
        patientService = new PatientService();

        loadPatients();
        loadCheckupData();

        addButton.addActionListener(e -> addCheckup());
        updateButton.addActionListener(e -> JOptionPane.showMessageDialog(this, "Update checkup feature not implemented yet"));
        deleteButton.addActionListener(e -> JOptionPane.showMessageDialog(this, "Delete checkup feature not implemented yet"));
        clearButton.addActionListener(e -> clearFields());
    }

    private void loadPatients() {
        List<Patient> patients = patientService.getAllPatients();
        patientCombo.removeAllItems();
        for (Patient p : patients) {
            patientCombo.addItem(p.getId() + " - " + p.getName());
        }
    }

    private void addCheckup() {
        try {
            String selected = (String) patientCombo.getSelectedItem();
            if (selected == null) {
                JOptionPane.showMessageDialog(this, "Select a patient");
                return;
            }
            int patientId = Integer.parseInt(selected.split(" - ")[0].trim());
            String doctor = doctorField.getText().trim();
            String date = dateField.getText().trim();
            String time = timeField.getText().trim();
            String symptoms = symptomsArea.getText().trim();
            String remarks = prescriptionArea.getText().trim();

            Checkup c = new Checkup(0, patientId, date, "120/80", "70kg", symptoms, remarks);
            checkupService.addCheckup(c);
            JOptionPane.showMessageDialog(this, "Checkup added!");
            loadCheckupData();
            clearFields();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error adding checkup: " + ex.getMessage());
        }
    }

    private void loadCheckupData() {
        try {
            List<Checkup> checkups = checkupService.getAllCheckups();
            String[] columns = {"ID", "Patient ID", "Date", "Blood Pressure", "Weight", "Symptoms", "Remarks"};
            Object[][] data = new Object[checkups.size()][7];
            for (int i = 0; i < checkups.size(); i++) {
                Checkup c = checkups.get(i);
                data[i][0] = c.getId();
                data[i][1] = c.getPatientId();
                data[i][2] = c.getDate();
                data[i][3] = c.getBloodPressure();
                data[i][4] = c.getWeight();
                data[i][5] = c.getSymptoms();
                data[i][6] = c.getRemarks();
            }
            checkupTable.setModel(new DefaultTableModel(data, columns));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading checkup data: " + e.getMessage());
        }
    }

    private void clearFields() {
        patientCombo.setSelectedIndex(-1);
        doctorField.setText("");
        dateField.setText("");
        timeField.setText("");
        symptomsArea.setText("");
        prescriptionArea.setText("");
        checkupTable.clearSelection();
    }
}
