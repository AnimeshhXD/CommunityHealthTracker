package ui;

import javax.swing.*;
import java.awt.*;

public class DashboardFrame extends JFrame {

    private JButton managePatientButton;
    private JButton recordCheckupsButton;
    private JButton viewReportsButton;
    private JButton logoutButton;

    public DashboardFrame() {
        setTitle("Dashboard");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1, 20, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        managePatientButton = new JButton("Manage Patients");
        recordCheckupsButton = new JButton("Record Checkups");
        viewReportsButton = new JButton("View Reports");
        logoutButton = new JButton("Logout");

        Font buttonFont = new Font("Segoe UI", Font.PLAIN, 16);
        managePatientButton.setFont(buttonFont);
        recordCheckupsButton.setFont(buttonFont);
        viewReportsButton.setFont(buttonFont);
        logoutButton.setFont(buttonFont);

        panel.add(managePatientButton);
        panel.add(recordCheckupsButton);
        panel.add(viewReportsButton);
        panel.add(logoutButton);

        add(panel, BorderLayout.CENTER);

        managePatientButton.addActionListener(e -> {
            PatientFrame pf = new PatientFrame();
            pf.setVisible(true);
        });

        recordCheckupsButton.addActionListener(e -> {
            CheckupFrame cf = new CheckupFrame();
            cf.setVisible(true);
        });

        viewReportsButton.addActionListener(e -> {
            ReportFrame rf = new ReportFrame();
            rf.setVisible(true);
        });

        logoutButton.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });
    }
}
