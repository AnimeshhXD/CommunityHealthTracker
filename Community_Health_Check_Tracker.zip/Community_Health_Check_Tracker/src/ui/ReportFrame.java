package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import Service.ReportService;
import model.Report;

public class ReportFrame extends JFrame {
    private JTable reportTable;
    private ReportService reportService;
    private JTextField searchField;
    private JButton searchButton, viewAllButton;

    public ReportFrame() {
        setTitle("Reports");
        setSize(650, 400);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel searchLabel = new JLabel("Enter Patient ID:");
        searchLabel.setBounds(20, 20, 120, 25);
        add(searchLabel);

        searchField = new JTextField();
        searchField.setBounds(150, 20, 150, 25);
        add(searchField);

        searchButton = new JButton("Search");
        searchButton.setBounds(320, 20, 100, 25);
        add(searchButton);

        viewAllButton = new JButton("View All");
        viewAllButton.setBounds(430, 20, 100, 25);
        add(viewAllButton);

        reportTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(reportTable);
        scrollPane.setBounds(20, 60, 600, 300);
        add(scrollPane);

        reportService = new ReportService();

        loadAllReports();

        searchButton.addActionListener(e -> searchReports());
        viewAllButton.addActionListener(e -> loadAllReports());
    }

    private void loadAllReports() {
        try {
            List<Report> reports = reportService.getAllReports();
            String[] columns = {"Patient ID", "Report Date", "Description"};
            Object[][] data = new Object[reports.size()][3];
            for (int i = 0; i < reports.size(); i++) {
                Report r = reports.get(i);
                data[i][0] = r.getPatientId();
                data[i][1] = r.getReportDate();
                data[i][2] = r.getDescription();
            }
            reportTable.setModel(new DefaultTableModel(data, columns));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading reports: " + ex.getMessage());
        }
    }

    private void searchReports() {
        try {
            int patientId = Integer.parseInt(searchField.getText().trim());
            List<Report> reports = reportService.getReportsByPatientId(patientId);
            String[] columns = {"Patient ID", "Report Date", "Description"};
            Object[][] data = new Object[reports.size()][3];
            for (int i = 0; i < reports.size(); i++) {
                Report r = reports.get(i);
                data[i][0] = r.getPatientId();
                data[i][1] = r.getReportDate();
                data[i][2] = r.getDescription();
            }
            reportTable.setModel(new DefaultTableModel(data, columns));
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Please enter a valid Patient ID.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error searching reports: " + ex.getMessage());
        }
    }
}
