package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import Service.PatientService;
import model.Patient;
import java.util.List;

public class PatientFrame extends JFrame {

    private JTextField nameField, ageField, contactField, addressField;
    private JComboBox<String> genderCombo;
    private JButton addButton, updateButton, deleteButton, clearButton;
    private JTable patientTable;
    private PatientService patientService;

    public PatientFrame() {
        setTitle("Manage Patients");
        setSize(700, 500);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(30, 30, 100, 25);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(140, 30, 200, 25);
        add(nameField);

        JLabel ageLabel = new JLabel("Age:");
        ageLabel.setBounds(30, 70, 100, 25);
        add(ageLabel);

        ageField = new JTextField();
        ageField.setBounds(140, 70, 200, 25);
        add(ageField);

        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setBounds(30, 110, 100, 25);
        add(genderLabel);

        genderCombo = new JComboBox<>(new String[] { "Male", "Female", "Other" });
        genderCombo.setBounds(140, 110, 200, 25);
        add(genderCombo);

        JLabel contactLabel = new JLabel("Contact:");
        contactLabel.setBounds(30, 150, 100, 25);
        add(contactLabel);

        contactField = new JTextField();
        contactField.setBounds(140, 150, 200, 25);
        add(contactField);

        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setBounds(30, 190, 100, 25);
        add(addressLabel);

        addressField = new JTextField();
        addressField.setBounds(140, 190, 200, 25);
        add(addressField);

        addButton = new JButton("Add");
        addButton.setBounds(50, 240, 100, 30);
        add(addButton);

        updateButton = new JButton("Update");
        updateButton.setBounds(180, 240, 100, 30);
        add(updateButton);

        deleteButton = new JButton("Delete");
        deleteButton.setBounds(310, 240, 100, 30);
        add(deleteButton);

        clearButton = new JButton("Clear");
        clearButton.setBounds(440, 240, 100, 30);
        add(clearButton);

        patientTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(patientTable);
        scrollPane.setBounds(30, 280, 650, 150);
        add(scrollPane);

        patientService = new PatientService();

        loadPatientData();

        addButton.addActionListener(e -> addPatient());
        updateButton.addActionListener(e -> updatePatient());
        deleteButton.addActionListener(e -> deletePatient());
        clearButton.addActionListener(e -> clearFields());

        patientTable.getSelectionModel().addListSelectionListener(event -> {
            if (!event.getValueIsAdjusting() && patientTable.getSelectedRow() != -1) {
                int row = patientTable.getSelectedRow();
                nameField.setText(patientTable.getValueAt(row, 1).toString());
                ageField.setText(patientTable.getValueAt(row, 2).toString());
                genderCombo.setSelectedItem(patientTable.getValueAt(row, 3).toString());
                contactField.setText(patientTable.getValueAt(row, 4).toString());
                addressField.setText(patientTable.getValueAt(row, 5).toString());
            }
        });
    }

    private void loadPatientData() {
        try {
            List<Patient> patients = patientService.getAllPatients();
            String[] columns = { "ID", "Name", "Age", "Gender", "Contact", "Address" };
            Object[][] data = new Object[patients.size()][6];
            for (int i = 0; i < patients.size(); i++) {
                Patient p = patients.get(i);
                data[i][0] = p.getId();
                data[i][1] = p.getName();
                data[i][2] = p.getAge();
                data[i][3] = p.getGender();
                data[i][4] = p.getContact();
                data[i][5] = p.getAddress();
            }
            patientTable.setModel(new DefaultTableModel(data, columns));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + ex.getMessage());
        }
    }

    private void addPatient() {
        try {
            Patient p = new Patient(0, nameField.getText(), Integer.parseInt(ageField.getText()),
                    (String) genderCombo.getSelectedItem(), contactField.getText(), addressField.getText());
            patientService.addPatient(p);
            JOptionPane.showMessageDialog(this, "Patient added!");
            loadPatientData();
            clearFields();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error adding patient: " + ex.getMessage());
        }
    }

    private void updatePatient() {
        try {
            int selectedRow = patientTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Select a patient to update.");
                return;
            }
            int id = (Integer) patientTable.getValueAt(selectedRow, 0);
            Patient p = new Patient(id, nameField.getText(), Integer.parseInt(ageField.getText()),
                    (String) genderCombo.getSelectedItem(), contactField.getText(), addressField.getText());
            patientService.updatePatient(p);
            JOptionPane.showMessageDialog(this, "Patient updated!");
            loadPatientData();
            clearFields();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error updating patient: " + ex.getMessage());
        }
    }

    private void deletePatient() {
        try {
            int selectedRow = patientTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Select a patient to delete.");
                return;
            }
            int id = (Integer) patientTable.getValueAt(selectedRow, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure to delete the selected patient?");
            if (confirm == JOptionPane.YES_OPTION) {
                patientService.deletePatient(id);
                JOptionPane.showMessageDialog(this, "Patient deleted!");
                loadPatientData();
                clearFields();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error deleting patient: " + ex.getMessage());
        }
    }

    private void clearFields() {
        nameField.setText("");
        ageField.setText("");
        genderCombo.setSelectedIndex(0);
        contactField.setText("");
        addressField.setText("");
        patientTable.clearSelection();
    }
}
