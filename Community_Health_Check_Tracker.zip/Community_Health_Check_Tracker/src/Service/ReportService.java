package Service;

import model.Report;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReportService {

    public List<Report> getAllReports() {
        List<Report> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection()) {
            String sql = "SELECT * FROM reports";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                Report r = new Report(
                        rs.getInt("id"),
                        rs.getInt("patientId"),
                        rs.getString("reportDate"),
                        rs.getString("description")
                );
                list.add(r);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public List<Report> getReportsByPatientId(int patientId) {
        List<Report> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection()) {
            String sql = "SELECT * FROM reports WHERE patientId=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, patientId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Report r = new Report(
                        rs.getInt("id"),
                        rs.getInt("patientId"),
                        rs.getString("reportDate"),
                        rs.getString("description")
                );
                list.add(r);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
