package model;

public class Report {
    private int id;
    private int patientId;
    private String reportDate;
    private String description;

    public Report(int id, int patientId, String reportDate, String description) {
        this.id = id;
        this.patientId = patientId;
        this.reportDate = reportDate;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public int getPatientId() {
        return patientId;
    }

    public String getReportDate() {
        return reportDate;
    }

    public String getDescription() {
        return description;
    }
}
