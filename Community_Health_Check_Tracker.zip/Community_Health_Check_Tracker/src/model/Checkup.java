package model;

public class Checkup {
    private int id;
    private int patientId;
    private String date;
    private String bloodPressure;
    private String weight;
    private String symptoms;
    private String remarks;

    public Checkup() {}

    public Checkup(int id, int patientId, String date, String bloodPressure,
                   String weight, String symptoms, String remarks) {
        this.id = id;
        this.patientId = patientId;
        this.date = date;
        this.bloodPressure = bloodPressure;
        this.weight = weight;
        this.symptoms = symptoms;
        this.remarks = remarks;
    }


    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getPatientId() { return patientId; }
    public void setPatientId(int patientId) { this.patientId = patientId; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public String getBloodPressure() { return bloodPressure; }
    public void setBloodPressure(String bloodPressure) { this.bloodPressure = bloodPressure; }

    public String getWeight() { return weight; }
    public void setWeight(String weight) { this.weight = weight; }

    public String getSymptoms() { return symptoms; }
    public void setSymptoms(String symptoms) { this.symptoms = symptoms; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
}
